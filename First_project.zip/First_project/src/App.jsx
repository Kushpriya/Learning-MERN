import React from "react";

class App extends React.Component{
  render(){
    return <div><h1>Hello World!!!</h1>
    <p>My name is Priya Kushawaha</p>
    <table border={5}>
      <tr>
        <th>SN</th>
        <th>Name</th>
        <th>Age</th>
        <th>Address</th>
      </tr>
      <tr>
        <td>1.</td>
        <td>Ram</td>
        <td>22</td>
        <td>ktm</td>
      </tr>
   
      <tr>
        <td>2.</td>
        <td>Rama</td>
        <td>20</td>
        <td>ktm</td>
      </tr>
      <tr>
        <td>3.</td>
        <td>Hari</td>
        <td>22</td>
        <td>Pokhara</td>
      </tr>
      </table>
    </div>
  }
}

export default App;
